var UploadWorkerSetUpAxiosMessage = (function () {
    function UploadWorkerSetUpAxiosMessage() {
        this.Headers = {};
    }
    return UploadWorkerSetUpAxiosMessage;
}());
//# sourceMappingURL=UploadWorkerSetUpAxiosMessage.js.map