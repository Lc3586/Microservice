var UploadConfigAuthoritiesTreeList = (function () {
    function UploadConfigAuthoritiesTreeList() {
    }
    return UploadConfigAuthoritiesTreeList;
}());
//# sourceMappingURL=UploadConfigAuthoritiesTreeList.js.map