var UploadConfigTreeList = (function () {
    function UploadConfigTreeList() {
    }
    return UploadConfigTreeList;
}());
//# sourceMappingURL=UploadConfigTreeList.js.map