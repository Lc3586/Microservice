﻿/**
 * 令牌信息
 * */
class TokenInfo {
    /**
     * 访问令牌
     */
    AccessToken: string;

    /**
     * 创建时间
     */
    Created: Date;

    /**
     * 过期时间
     */
    Expires: Date;
}