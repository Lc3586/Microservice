var UploadConfigDetail = (function () {
    function UploadConfigDetail() {
    }
    return UploadConfigDetail;
}());
//# sourceMappingURL=UploadConfigDetail.js.map