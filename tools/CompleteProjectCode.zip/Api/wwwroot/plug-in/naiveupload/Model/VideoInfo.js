var VideoInfo = (function () {
    function VideoInfo() {
    }
    return VideoInfo;
}());
var StreamInfo = (function () {
    function StreamInfo() {
    }
    return StreamInfo;
}());
var DispositionInfo = (function () {
    function DispositionInfo() {
    }
    return DispositionInfo;
}());
var StreamTagsInfo = (function () {
    function StreamTagsInfo() {
    }
    return StreamTagsInfo;
}());
var FormatInfo = (function () {
    function FormatInfo() {
    }
    return FormatInfo;
}());
var ChapterInfo = (function () {
    function ChapterInfo() {
    }
    return ChapterInfo;
}());
var ProgramInfo = (function () {
    function ProgramInfo() {
    }
    return ProgramInfo;
}());
var ProgramVersionInfo = (function () {
    function ProgramVersionInfo() {
    }
    return ProgramVersionInfo;
}());
var LibraryVersionInfo = (function () {
    function LibraryVersionInfo() {
    }
    return LibraryVersionInfo;
}());
//# sourceMappingURL=VideoInfo.js.map