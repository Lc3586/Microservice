var ChunksSourceInfo = (function () {
    function ChunksSourceInfo() {
    }
    return ChunksSourceInfo;
}());
//# sourceMappingURL=ChunksSourceInfo.js.map