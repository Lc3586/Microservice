var ChunkFileMergeTask = (function () {
    function ChunkFileMergeTask() {
    }
    return ChunkFileMergeTask;
}());
//# sourceMappingURL=ChunkFileMergeTask.js.map