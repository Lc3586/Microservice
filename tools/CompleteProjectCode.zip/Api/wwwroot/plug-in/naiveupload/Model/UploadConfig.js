var UploadConfig = (function () {
    function UploadConfig() {
    }
    return UploadConfig;
}());
//# sourceMappingURL=UploadConfig.js.map