var PersonalFileInfo = (function () {
    function PersonalFileInfo() {
    }
    return PersonalFileInfo;
}());
//# sourceMappingURL=PersonalFileInfo.js.map