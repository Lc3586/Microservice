var AppendFileResult = (function () {
    function AppendFileResult() {
    }
    return AppendFileResult;
}());
//# sourceMappingURL=AppendFileResult.js.map