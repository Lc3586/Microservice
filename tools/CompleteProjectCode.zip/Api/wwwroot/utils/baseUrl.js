﻿if ('undefined' === typeof window)
    window = {};
window.BaseUrl = '/simple-api';