﻿using Business.Interface.Services.Example;
using Business.Utils;

namespace Business.Implementation.Services.Example
{
    /// <summary>
    /// 示例Soap服务业务类
    /// </summary>
    public class SampleBusiness : BaseBusiness, ISampleBusiness
    {

    }
}
