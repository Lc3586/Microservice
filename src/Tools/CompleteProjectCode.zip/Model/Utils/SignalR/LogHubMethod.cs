﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Utils.SignalR
{
    /// <summary>
    /// 日志中心前端方法
    /// </summary>
    public struct LogHubMethod
    {
        public const string Log = "ReceiveLog";
    }
}
