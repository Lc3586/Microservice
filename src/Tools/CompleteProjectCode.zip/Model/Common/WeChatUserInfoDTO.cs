﻿using Entity.Common;
using Microservice.Library.DataMapping.Annotations;
using Microservice.Library.OpenApi.Annotations;
using System.Collections.Generic;
using System.ComponentModel;

/* 
 * 微信业务模型
 */
namespace Model.Common.WeChatUserInfoDTO
{
    /// <summary>
    /// 列表
    /// </summary>
    [MapFrom(typeof(Common_WeChatUserInfo))]
    [OpenApiMainTag("List")]
    public class List : Common_WeChatUserInfo
    {

    }

    /// <summary>
    /// 详情
    /// </summary>
    [MapFrom(typeof(Common_WeChatUserInfo))]
    [OpenApiMainTag("Detail")]
    public class Detail : Common_WeChatUserInfo
    {
        /// <summary>
        /// 用户详情
        /// </summary>
        [OpenApiSchema(OpenApiSchemaType.model)]
        [Description("用户详情")]
        public List<System.UserDTO.Detail> _Users { get; set; }
        /// <summary>
        /// 用户详情
        /// </summary>
        [OpenApiSchema(OpenApiSchemaType.model)]
        [Description("用户详情")]
        public List<Public.MemberDTO.Detail> _Members { get; set; }
    }

    /// <summary>
    /// 微信网页授权时携带的参数信息
    /// </summary>
    public class StateInfo
    {
        /// <summary>
        /// 类型
        /// </summary>
        public WeChatStateType Type { get; set; }

        /// <summary>
        /// 数据
        /// </summary>
        public Dictionary<string, object> Data { get; set; }

        /// <summary>
        /// 重定向地址
        /// </summary>
        public string RedirectUrl { get; set; }
    }

    /// <summary>
    /// 链接信息
    /// </summary>
    public class UrlInfo
    {
        /// <summary>
        /// 用于生成二维码的链接
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 用于连接Signalr的字符串
        /// </summary>
        public string S { get; set; }
    }
}
