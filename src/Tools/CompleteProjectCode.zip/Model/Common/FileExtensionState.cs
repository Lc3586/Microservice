﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Common
{
    /// <summary>
    /// 文件拓展信息状态
    /// </summary>
    public static class FileExtensionState
    {
        public const string 可用 = "可用";

        public const string 锁定 = "锁定";
    }
}
