﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Common
{
    /// <summary>
    /// 上传类型
    /// </summary>
    public enum UploadType
    {
        SingleImage,
        Single
    }
}
