﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Example
{
    /// <summary>
    /// Soap服务测试枚举
    /// </summary>
    public enum SoapTestEnum
    {
        One,
        Two
    }
}
