﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Interface.Services.Example
{
    /// <summary>
    /// 示例Soap服务接口类
    /// </summary>
    public interface ISampleBusiness
    {

    }
}
