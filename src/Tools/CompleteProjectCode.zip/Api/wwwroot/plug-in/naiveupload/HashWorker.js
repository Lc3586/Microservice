if ('undefined' === typeof window && 'function' === typeof importScripts) {
    importScripts("../../utils/spark-md5.min.js");
    addEventListener('message', onMessage);
    var spark_1 = new self.SparkMD5.ArrayBuffer();
    function onMessage(event) {
        var data = event.data;
        if (data instanceof ArrayBuffer) {
            console.info('ArrayBuffer');
            spark_1.append(data);
        }
        else {
            self.postMessage(spark_1.end(), '*');
            close();
        }
    }
}
//# sourceMappingURL=HashWorker.js.map