if ('undefined' === typeof window && 'function' === typeof importScripts) {
    importScripts("/HashWorker.js");
    addEventListener('message', onMessage);
    var fileList_1 = [];
    function onMessage(event) {
        var data = event.data;
        if (data instanceof ArrayBuffer) {
            console.info('ArrayBuffer');
            data;
        }
        else {
            console.info('UploadWorkerMethod');
            switch (data) {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    close();
                    break;
                default:
            }
        }
        function CreateTask(buffer) {
            fileList_1.push();
        }
    }
}
//# sourceMappingURL=HandlerUploadWorker.js.map