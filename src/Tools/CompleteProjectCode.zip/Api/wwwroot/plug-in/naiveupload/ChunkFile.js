var ChunkFile = (function () {
    function ChunkFile(index, blob) {
        this.Checking = false;
        this.Checked = false;
        this.Uploading = false;
        this.Uploaded = false;
        this.Error = false;
        this.Percent = 0;
        this.Index = index;
        this.Blob = blob;
    }
    return ChunkFile;
}());
//# sourceMappingURL=ChunkFile.js.map