﻿/**
 * 上传文件Worker支持的方法
 * */
const enum UploadWorkerMethod {
    下行_开始,
    下行_暂停,
    下行_恢复,
    下行_取消,
    上行_异常
}