﻿// proper initialization
if ('undefined' === typeof window && 'function' === typeof importScripts) {
    importScripts("/HashWorker.js");
    addEventListener('message', onMessage);

    let fileList: RawFile[] = [];

    /**
     * 接收消息
     * @param event
     */
    function onMessage(event: MessageEvent<UploadWorkerMethod | ArrayBuffer>) {
        // do some work here 
        let data = event.data;
        if (data instanceof ArrayBuffer) {
            console.info('ArrayBuffer');

            (<ArrayBuffer>data);
        } else {
            console.info('UploadWorkerMethod');
            switch (<UploadWorkerMethod>data) {
                case UploadWorkerMethod.下行_开始:

                    break;
                case UploadWorkerMethod.下行_暂停:

                    break;
                case UploadWorkerMethod.下行_恢复:

                    break;
                case UploadWorkerMethod.下行_取消:
                    close();
                    break;
                default:
            }
        }

        /**
         * 创建任务
         * */
        function CreateTask(buffer: ArrayBuffer) {
            fileList.push();
        }




        //const { fileChunkList } = event.data;
        //const spark = new self.SparkMD5.ArrayBuffer();
        //let percentage = 0;
        //let count = 0;
        //const loadNext = index => {
        //    const reader = new FileReader();
        //    reader.readAsArrayBuffer(fileChunkList[index].file);
        //    reader.onload = e => {
        //        count++;
        //        spark.append(e.target.result);
        //        if (count === fileChunkList.length) {
        //            self.postMessage({
        //                percentage: 100,
        //                hash: spark.end()
        //            });
        //            self.close();
        //        } else {
        //            percentage += 100 / fileChunkList.length;
        //            self.postMessage({
        //                percentage
        //            });
        //            loadNext(count);
        //        }
        //    };
        //};
        //loadNext(0);
    }
}
