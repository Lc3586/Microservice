window.onload = function () {
    window.importFile([
        {
            tag: 'link',
            type: 'text/css',
            rel: 'stylesheet',
            href: '../../element-plus/theme-chalk/element-plus.index.css'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../vue/vue.global.prod.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../utils/axios.min.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../element-plus/element-plus.index.full.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../element-plus/element-plus.es.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../element-plus/element-plus.zh-cn.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../element-plus/dayjs.zh-cn.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: '../../utils/lodash.min.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: 'MultipleUploadSetting.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: 'SelectedFile.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: 'RawFile.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: 'ChunkFile.js'
        },
        {
            tag: 'script',
            type: 'text/javascript',
            src: 'ApiUri.js'
        },
    ], function () {
        var vue = window.Vue;
        var elementPlus = window.ElementPlus;
        var axios = window.axios;
        var promise = window.Promise;
        var _ = window._;
        var main;
        var multipleUploadSettings = new MultipleUploadSetting();
        var rawFileList = [];
        var selectedFileList = [];
        var appData = {
            data: GetRenderData,
            created: function () {
                main = this;
                addLoginFilter();
            },
            methods: {
                saLogin: saLogin,
                tabsChanged: tabsChanged,
                getSelectCLass: getSelectCLass,
                getSelectTitle: getSelectTitle,
                selectFile: selectFile,
                allowDrop: allowDrop,
                dropFile: dropFile,
                selectedFile: selectedFile,
                getListCLass: getListCLass,
                getContainerClass: getContainerClass,
                getContainerTitle: getContainerTitle,
                getFilename: getFilename,
                showTools: showTools,
                showLoading: showLoading,
                getLoadingStyle: getLoadingStyle,
                getLoadingTitle: getLoadingTitle,
                enableRename: enableRename,
                rename: rename,
                renameKeydown: renameKeydown,
                enableView: enableView,
                view: view,
                remove: remove,
                start: start,
                pause: pause,
                continues: continues,
                clean: clean
            },
            watch: {
                'multipleUpload.settings': {
                    handler: function (val) {
                        for (var key in val) {
                            if (multipleUploadSettings[key] != val[key])
                                multipleUploadSettings[key] = val[key];
                        }
                    },
                    deep: true
                },
                'multipleUpload.files': {
                    handler: function (val) {
                        var _this = this;
                        if (!this.multipleUpload.scrollLock)
                            return;
                        this.$nextTick(function () {
                            var container;
                            for (var i = 0; i < val.length; i++) {
                                var file = val[i];
                                if (file.uploading) {
                                    container = _this.$refs['file_container_' + i];
                                    break;
                                }
                            }
                            if (!container)
                                container = _this.$refs['file_container_' + (val.length - 1)];
                            _this.$refs.uploadList.scrollTop = container.offsetTop;
                        });
                    },
                    deep: true
                }
            }
        };
        var App = vue.createApp(appData);
        elementPlus.locale(elementPlus.lang.zhCn);
        App.use(elementPlus);
        App.mount("#app");
        function GetRenderData() {
            return {
                loading: true,
                sa: {
                    show: false,
                    loading: true,
                    username: '',
                    password: ''
                },
                config: {
                    type: 'Multiple'
                },
                single: {
                    settings: {},
                    file: {}
                },
                multipleUpload: {
                    settings: {
                        Accept: multipleUploadSettings.Accept,
                        MultipleSelect: multipleUploadSettings.MultipleSelect,
                        Explain: multipleUploadSettings.Explain,
                        Tip: multipleUploadSettings.Tip,
                        Theme: multipleUploadSettings.Theme
                    },
                    scrollLock: true,
                    files: selectedFileList
                }
            };
        }
        function addLoginFilter() {
            axios.interceptors.response.use(function (response) {
                return response;
            }, function (error) {
                if (error && error.response && error.response.status == 401)
                    main.sa.show ? 1 : main.sa.show = true;
                else if (error && error.response && error.response.status == 403) {
                    error.message = "无权限!";
                    return promise.reject(error);
                }
                else
                    return promise.reject(error);
            });
        }
        function saLogin() {
            main.sa.loading = true;
            axios.post(ApiUri.SALogin, {
                Account: main.sa.username,
                Password: main.sa.password
            }).then(function (response) {
                main.sa.loading = false;
                if (response.data.Success) {
                    main.sa.username = '';
                    main.sa.Password = '';
                    main.sa.show = false;
                }
                else
                    elementPlus.ElMessage(response.data.Message);
            }).catch(function (error) {
                main.sa.loading = false;
                elementPlus.ElMessage('SA身份验证时发生异常.');
            });
        }
        function tabsChanged(tab) {
            main.config.type = tab.props.name;
            switch (tab.props.name) {
                case 'Signle':
                default:
                    break;
                case 'Multiple':
                    break;
            }
        }
        function limited() {
            return !!multipleUploadSettings.Limit && main.multipleUpload.files.length >= multipleUploadSettings.Limit;
        }
        function getListCLass() {
            return "upload-" + main.multipleUpload.settings.Theme + "-list";
        }
        function getSelectCLass() {
            return "upload-drag " + (limited() ? 'item-limited' : '');
        }
        function getSelectTitle() {
            if (!multipleUploadSettings.Limit)
                return null;
            return main.multipleUpload.files.length < multipleUploadSettings.Limit ? "\u8FD8\u53EF\u6DFB\u52A0\u4E2A" + (multipleUploadSettings.Limit - main.multipleUpload.files.length) + "\u6587\u4EF6" : "\u6587\u4EF6\u6570\u91CF\u5DF2\u8FBE\u4E0A\u9650";
        }
        function selectFile(e) {
            if (limited())
                return;
            main.$refs.fileInput.click();
        }
        function allowDrop(e) {
            e.preventDefault();
        }
        function dropFile(e) {
            e.preventDefault();
            appendFiles(e.dataTransfer.files);
        }
        function selectedFile(e) {
            appendFiles(main.$refs.fileInput.files);
        }
        function appendFiles(files) {
            if (!!multipleUploadSettings.Limit && (main.multipleUpload.files.length + files.length) > multipleUploadSettings.Limit) {
                elementPlus.ElMessage("\u6700\u591A\u53EA\u80FD\u6DFB\u52A0" + multipleUploadSettings.Limit + "\u4E2A\u6587\u4EF6.");
            }
            var push = function (file, newFile) {
                rawFileList.push(new RawFile(file));
                newFile.RawIndex = rawFileList.length - 1;
                main.multipleUpload.files.push(newFile);
                handleFile(_.last(main.multipleUpload.files));
            };
            var fileList = Array.prototype.slice.call(files);
            var _loop_1 = function (file) {
                if (limited())
                    return { value: void 0 };
                var pointIndex = file.name.lastIndexOf('.');
                var selectedFile_1 = new SelectedFile(file);
                if (multipleUploadSettings.BeforeUpload) {
                    var before = multipleUploadSettings.BeforeUpload(file);
                    if (before && before.then) {
                        before.then(function (flag) {
                            if (flag)
                                push(file, selectedFile_1);
                        });
                    }
                }
                else
                    push(file, selectedFile_1);
            };
            for (var _i = 0, fileList_1 = fileList; _i < fileList_1.length; _i++) {
                var file = fileList_1[_i];
                var state_1 = _loop_1(file);
                if (typeof state_1 === "object")
                    return state_1.value;
            }
        }
        function handleFile(selectedFile) {
            selectedFile.Thumbnail = ApiUri.FileTypeImageUrl(selectedFile.ExtensionLower);
            getFileType(selectedFile, function () {
                checkImage(selectedFile);
            });
            getFileSize(selectedFile);
            if ('undefined' == typeof Worker) {
                selectedFile.Error = true;
                selectedFile.ErrorMessage = '当前浏览器不支持Web Worker，无法上传.';
                return;
            }
            console.info(selectedFile);
            var rawFile = getRawFile(selectedFile);
            console.info(rawFile);
            var reader = new FileReader();
            reader.onloadend = function (event) {
                console.info(event.loaded / event.total);
            };
            reader.onprogress = function (event) {
                console.info(event.loaded / event.total);
            };
            reader.onload = function (event) {
                console.info('ok');
                console.info(event.target.result.byteLength);
            };
            reader.readAsArrayBuffer(rawFile.File.slice(0, rawFile.File.size));
            console.info(rawFile.File.size);
        }
        function getRawFile(selectedFile) {
            return rawFileList[selectedFile.RawIndex];
        }
        function getChunks(selectedFile) {
            var file = getRawFile(selectedFile);
            if (file.File.size > multipleUploadSettings.ChunkSize)
                file.NeedSection = true;
            else
                return;
            var count = 0;
            while (count < file.File.size) {
                file.ChunkIndexQueue.push(file.Chunks.length);
                file.Chunks.push(new ChunkFile(file.Chunks.length, file.File.slice(count, count + multipleUploadSettings.ChunkSize)));
                count += multipleUploadSettings.ChunkSize;
            }
        }
        function getFileType(selectedFile, done) {
            var file = getRawFile(selectedFile);
            var api = file.File.type == null || file.File.type == '' || file.File.type == 'application/octet-stream' ? ApiUri.FileTypeByExtension(selectedFile.ExtensionLower) : ApiUri.FileTypeByMIME(file.File.type);
            axios.get(api)
                .then(function (response) {
                if (response.data.Success)
                    selectedFile.FileType = response.data.Data;
                else
                    selectedFile.FileType = "\u672A\u77E5";
                done && done();
            })
                .catch(function (error) {
                selectedFile.FileType = "\u672A\u77E5";
            });
        }
        function checkImage(selectedFile) {
            if (selectedFile.FileType != "\u56FE\u7247")
                return;
            selectedFile.Thumbnail = getRawFile(selectedFile).ObjectURL;
        }
        function getFileSize(selectedFile) {
            axios.get(ApiUri.FileSize(getRawFile(selectedFile).File.size))
                .then(function (response) {
                if (response.data.Success)
                    selectedFile.Size = response.data.Data;
                else
                    selectedFile.Size = '-';
            })
                .catch(function (error) {
                selectedFile.Size = '-';
            });
        }
        function getContainerClass(selectedFile) {
            return "item-container " + (selectedFile.Done ? ' item-done' : '') + " " + (selectedFile.Error ? ' item-error' : '') + " " + (selectedFile.Hover && !selectedFile.Rename && !selectedFile.Checking && !selectedFile.Uploading ? ' item-hover' : '') + " " + (selectedFile.Checking ? ' item-checking' : '') + " " + (selectedFile.Uploading ? ' item-uploading' : '');
        }
        function getContainerTitle(selectedFile) {
            return (selectedFile.Done ? '上传成功' : '') + " " + (selectedFile.Error ? selectedFile.ErrorMessage : '');
        }
        function getFilename(selectedFile) {
            return (selectedFile.Name || '-') + (selectedFile.Extension || '-');
        }
        function showTools(selectedFile) {
            return selectedFile.Hover && !selectedFile.Rename && !selectedFile.Checking && !selectedFile.Uploading;
        }
        function showLoading(selectedFile) {
            return !selectedFile.Rename && (selectedFile.Checking || selectedFile.Uploading);
        }
        function getGradientStyle(type, color, value1, value2) {
            switch (type) {
                default:
                case 'conic':
                    return "\nbackground: conic-gradient(" + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -moz-conic-gradient(" + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -o-conic-gradient(" + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -webkit-conic-gradient(" + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;";
                case 'linear':
                    return "\nbackground: linear-gradient(left, " + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -moz-linear-gradient(left, " + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -o-linear-gradient(left, " + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;\nbackground: -webkit-linear-gradient(left, " + color + " " + value1 + "%, transparent " + value2 + "%)  repeat scroll 0% 0%;";
            }
        }
        function getLoadingStyle(selectedFile) {
            var styleType = main.multipleUpload.settings.Theme == 'card' ? 'conic' : 'linear';
            return (selectedFile.Checking ? getGradientStyle(styleType, 'rgba(255, 152, 0, 0.3)', selectedFile.Percent, 0) : '') + " " + (selectedFile.Uploading ? getGradientStyle(styleType, 'rgba(144, 206, 255, 0.5)', selectedFile.Percent, selectedFile.VirtualPercent) : '');
        }
        function getLoadingTitle(selectedFile) {
            return (selectedFile.Checking ? ('扫描中...' + selectedFile.Percent + '%') : '') + " " + (selectedFile.Uploading ? ('上传中...' + selectedFile.Percent + '%') : '');
        }
        function enableRename(selectedFile) {
            return !selectedFile.Uploading && !selectedFile.Uploaded;
        }
        function rename(selectedFile) {
            selectedFile.Rename = true;
            main.$nextTick(function (_) {
                main.$refs.renameInput.focus();
            }, 100);
        }
        function renameKeydown(selectedFile, event) {
            if (event.keyCode == 13)
                selectedFile.Rename = false;
        }
        function enableView(selectedFile) {
            switch (selectedFile.FileType) {
                case "\u56FE\u7247":
                case "\u97F3\u9891":
                    return selectedFile.ExtensionLower != '.flac';
                case "\u89C6\u9891":
                    return true;
                case "\u6587\u672C\u6587\u4EF6":
                    return true;
                case "\u7535\u5B50\u6587\u6863":
                    return selectedFile.ExtensionLower == '.pdf';
                default:
                    return false;
            }
        }
        function view(selectedFile) {
            var file = getRawFile(selectedFile);
            var bodyStyle = "margin:0px;text-align: center;display: flex;flex-direction: row;justify-content: center;align-items: center;";
            switch (selectedFile.FileType) {
                case "\u56FE\u7247":
                    var winImage = window.open();
                    winImage.document.write("<body style=\"" + bodyStyle + "background-color: black;\"><img src=\"" + file.ObjectURL + "\" /img></body>");
                    break;
                case "\u97F3\u9891":
                    if (selectedFile.ExtensionLower == '.flac')
                        return;
                    var winAudio = window.open();
                    winAudio.document.write("<body style=\"" + bodyStyle + "background-color: black;\"><audio src=\"" + file.ObjectURL + "\" controls=\"controls\">\u62B1\u6B49, \u6682\u4E0D\u652F\u6301</audio></body>");
                    break;
                case "\u89C6\u9891":
                    var winVideo = window.open();
                    winVideo.document.write("<body style=\"" + bodyStyle + "background-color: black;\"><video src=\"" + file.ObjectURL + "\" controls=\"controls\">\u62B1\u6B49, \u6682\u4E0D\u652F\u6301</video></body>");
                    break;
                default:
                    var win = window.open();
                    win.document.write("<body style=\"" + bodyStyle + "\"><object data=\"" + file.ObjectURL + "\" type=\"" + (selectedFile.ExtensionLower == '.txt' ? 'text/plain' : (selectedFile.ExtensionLower == '.pdf' ? 'application/pdf' : 'application/octet-stream')) + "\" width=\"100%\" height=\"100%\"><iframe src=\"" + file.ObjectURL + "\" scrolling=\"no\" width=\"100%\" height=\"100%\" frameborder=\"0\" ></iframe></object></body>");
                    break;
            }
        }
        function remove(index) {
            main.multipleUpload.files.splice(index, 1);
        }
        function start() {
        }
        function pause() {
        }
        function continues() {
        }
        function clean() {
        }
    });
};
//# sourceMappingURL=NaiveUpload.js.map