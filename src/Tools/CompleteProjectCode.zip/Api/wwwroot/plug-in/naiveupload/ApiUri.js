var ApiUri = (function () {
    function ApiUri() {
    }
    ApiUri.PreUploadChunkfile = function (file_md5, md5, index, specs) {
        return "/file/pre-upload-chunkfile/" + file_md5 + "/" + md5 + "/" + index + "/" + specs;
    };
    ;
    ApiUri.UploadSingleChunkfile = function (key, md5) {
        return "/file/upload-single-chunkfile/" + key + "/" + md5;
    };
    ApiUri.UploadChunkfileFinished = function (file_md5, specs, total, filename) {
        return "/file/upload-chunkfile-finished/" + file_md5 + "/" + specs + "/" + total + "?filename=" + filename;
    };
    ApiUri.Preview = function (id, width, height, time) {
        return "/file/preview/" + id + "?width=" + width + "&height=" + height + "&time=" + time;
    };
    ApiUri.Browse = function (id) {
        return "/file/browse/" + id;
    };
    ApiUri.SALogin = '/sa/login';
    ApiUri.FileTypeByExtension = function (extension) { return "/file/file-type-by-extension/" + extension; };
    ApiUri.FileTypeByMIME = function (mimetype) { return "/file/file-type-by-mimetype?mimetype=" + mimetype; };
    ApiUri.FileTypeImageUrl = function (extension) { return "/file/file-type-image/" + extension; };
    ApiUri.FileSize = function (length) { return "/file/file-size/" + length; };
    ApiUri.ValidationFileMD5 = function (md5) { return "/file/validation-file-md5/" + md5; };
    return ApiUri;
}());
//# sourceMappingURL=ApiUri.js.map