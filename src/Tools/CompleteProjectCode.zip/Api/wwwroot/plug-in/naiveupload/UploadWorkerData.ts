﻿/**
 * 上传文件Worker接收的数据
 * */
class UploadWorkerData {
    /**
     * 方法
     */
    Method: UploadWorkerMethod;

    /***
     * 索引
     */
    Index: number;

    /***
     * 二进制数据
     */
    Blob: Blob;
}