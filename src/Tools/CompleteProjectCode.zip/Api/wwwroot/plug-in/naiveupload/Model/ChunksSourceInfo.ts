﻿/**
 * 分片来源信息
 * */
class ChunksSourceInfo {
    /***
     * 分片规格
     */
    Specs: string;

    /***
     * 总数
     */
    Total: string;

    /***
     * 热度信息
     */
    Activitys: ActivityInfo[];
}