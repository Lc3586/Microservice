var ActivityInfo = (function () {
    function ActivityInfo() {
    }
    return ActivityInfo;
}());
//# sourceMappingURL=ActivityInfo.js.map