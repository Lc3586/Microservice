var UploadWorkerCancelMessage = (function () {
    function UploadWorkerCancelMessage() {
    }
    return UploadWorkerCancelMessage;
}());
//# sourceMappingURL=UploadWorkerCancelMessage.js.map