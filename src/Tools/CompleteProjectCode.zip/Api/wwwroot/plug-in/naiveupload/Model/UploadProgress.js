var UploadProgress = (function () {
    function UploadProgress() {
    }
    return UploadProgress;
}());
//# sourceMappingURL=UploadProgress.js.map