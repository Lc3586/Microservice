var UploadWorkerNoticeMessage = (function () {
    function UploadWorkerNoticeMessage() {
    }
    return UploadWorkerNoticeMessage;
}());
//# sourceMappingURL=UploadWorkerNoticeMessage.js.map