﻿/**
 * 上传组件主题
 * */
const enum UploadTheme {
    卡片主题 = 'card',
    清单主题 = 'detailedly'
}