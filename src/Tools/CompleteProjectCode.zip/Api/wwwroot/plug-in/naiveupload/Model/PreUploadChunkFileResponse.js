var PreUploadChunkFileResponse = (function () {
    function PreUploadChunkFileResponse() {
    }
    return PreUploadChunkFileResponse;
}());
//# sourceMappingURL=PreUploadChunkFileResponse.js.map