var TokenInfo = (function () {
    function TokenInfo() {
    }
    return TokenInfo;
}());
//# sourceMappingURL=TokenInfo.js.map