var UploadWorkerChunkFileMessage = (function () {
    function UploadWorkerChunkFileMessage() {
    }
    return UploadWorkerChunkFileMessage;
}());
//# sourceMappingURL=UploadWorkerChunkFileMessage.js.map