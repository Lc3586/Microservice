﻿/**
 * 令牌信息
 * */
class TokenInfo {
    /**
     * 访问令牌
     */
    AccessToken: string;

    /**
     * 过期时间
     */
    Expires: Date;
}