var UploadWorkerMessage = (function () {
    function UploadWorkerMessage() {
    }
    return UploadWorkerMessage;
}());
//# sourceMappingURL=UploadWorkerMessage.js.map