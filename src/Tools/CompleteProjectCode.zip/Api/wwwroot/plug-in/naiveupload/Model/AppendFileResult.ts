﻿/**
 * 追加文件返回信息
 * */
class AppendFileResult {
    /**
     * 状态
     * */
    Status: AppendFileResultStatus;

    /**
     * 文件名称
     * */
    Name?: string[];
}