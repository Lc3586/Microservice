var UploadWorkerFileMessage = (function () {
    function UploadWorkerFileMessage() {
    }
    return UploadWorkerFileMessage;
}());
//# sourceMappingURL=UploadWorkerFileMessage.js.map