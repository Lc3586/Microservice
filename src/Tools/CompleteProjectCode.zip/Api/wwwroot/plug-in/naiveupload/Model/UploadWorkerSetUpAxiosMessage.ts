﻿/**
 * 文件上传子线程设置Axios信息
 * */
class UploadWorkerSetUpAxiosMessage {
    /**
     * 请求头设置
     */
    Headers: Record<string, string> = {};
}