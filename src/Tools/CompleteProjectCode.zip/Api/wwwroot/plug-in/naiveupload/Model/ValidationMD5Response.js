var ValidationMD5Response = (function () {
    function ValidationMD5Response() {
    }
    return ValidationMD5Response;
}());
//# sourceMappingURL=ValidationMD5Response.js.map