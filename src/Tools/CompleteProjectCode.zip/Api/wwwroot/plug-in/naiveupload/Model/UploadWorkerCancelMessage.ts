﻿/**
 * 文件上传子线程取消上传传输信息
 * */
class UploadWorkerCancelMessage {
    /**
     * 文件哈希值
     */
    MD5: string;
}