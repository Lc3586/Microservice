﻿/**
 * 热度信息
 * */
class ActivityInfo {
    /***
     * 热度
     */
    Activity: number;

    /***
     * 百分比
     */
    Percentage: number;
}