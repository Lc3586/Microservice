var FileInfo = (function () {
    function FileInfo() {
    }
    return FileInfo;
}());
//# sourceMappingURL=FileInfo.js.map