﻿/**
 * 源文件
 * */
class RawFile {
    /**
     * 
     * @param file 源文件
     */
    constructor(file: File) {
        this.File = file;
        this.ObjectURL = URL.createObjectURL(file);
    }

    /**
     * 文件
     */
    File: File;

    /**
     * 资源地址
     */
    ObjectURL: string;

    /**
     * 标识
     */
    Id: string;

    /**
     * 哈希值
     */
    MD5: string;

    /**
     * 需要切片处理
     */
    NeedSection: boolean = false;

    /**
     * 切片集合
     */
    Chunks: ChunkFile[] = [];

    /**
     * 切片索引队列
     */
    ChunkIndexQueue: number[] = [];
}