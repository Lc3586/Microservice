﻿// proper initialization
if ('undefined' === typeof window && 'function' === typeof importScripts) {
    importScripts("../../utils/spark-md5.min.js");
    addEventListener('message', onMessage);

    const spark = new (<any>self).SparkMD5.ArrayBuffer();

    /**
     * 接收消息
     * @param event
     */
    function onMessage(event: MessageEvent<ArrayBuffer | null>) {
        // do some work here 
        let data = event.data;
        if (data instanceof ArrayBuffer) {
            console.info('ArrayBuffer');
            spark.append(data);
        } else {
            self.postMessage(spark.end(), '*');
            close();
        }
    }
}
