var UploadWorkerData = (function () {
    function UploadWorkerData() {
    }
    return UploadWorkerData;
}());
//# sourceMappingURL=UploadWorkerData.js.map