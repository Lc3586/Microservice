﻿bash
service xvfb start;
dotnet SimpleApi.dll